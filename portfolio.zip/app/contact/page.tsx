import { getDb } from "@/lib/db"
import type { Metadata } from "next"
import ContactForm from "@/components/contact-form"

export const metadata: Metadata = {
  title: "Contact | Dynamic Portfolio",
  description: "Get in touch with me",
}

async function getProfile() {
  const db = await getDb()
  return db.get("SELECT * FROM profile LIMIT 1")
}

export default async function ContactPage() {
  const profile = await getProfile()

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">Contact Me</h1>
      <ContactForm profile={profile} />
    </div>
  )
}

