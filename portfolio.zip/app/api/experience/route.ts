import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await getDb()
    const experience = await db.all("SELECT * FROM experience ORDER BY start_date DESC")

    return NextResponse.json(experience)
  } catch (error) {
    console.error("Error fetching experience:", error)
    return NextResponse.json({ error: "Failed to fetch experience" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    const result = await db.run(
      `
      INSERT INTO experience (company, position, start_date, end_date, description, location)
      VALUES (?, ?, ?, ?, ?, ?)
    `,
      [data.company, data.position, data.start_date, data.end_date, data.description, data.location],
    )

    return NextResponse.json({ id: result.lastID, ...data })
  } catch (error) {
    console.error("Error creating experience:", error)
    return NextResponse.json({ error: "Failed to create experience" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    await db.run(
      `
      UPDATE experience 
      SET company = ?, position = ?, start_date = ?, end_date = ?, description = ?, location = ?
      WHERE id = ?
    `,
      [data.company, data.position, data.start_date, data.end_date, data.description, data.location, data.id],
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating experience:", error)
    return NextResponse.json({ error: "Failed to update experience" }, { status: 500 })
  }
}

