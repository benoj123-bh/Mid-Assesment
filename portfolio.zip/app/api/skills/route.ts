import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await getDb()
    const skills = await db.all("SELECT * FROM skills ORDER BY category, level DESC")

    return NextResponse.json(skills)
  } catch (error) {
    console.error("Error fetching skills:", error)
    return NextResponse.json({ error: "Failed to fetch skills" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    const result = await db.run(
      `
      INSERT INTO skills (category, name, level)
      VALUES (?, ?, ?)
    `,
      [data.category, data.name, data.level],
    )

    return NextResponse.json({ id: result.lastID, ...data })
  } catch (error) {
    console.error("Error creating skill:", error)
    return NextResponse.json({ error: "Failed to create skill" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    await db.run(
      `
      UPDATE skills 
      SET category = ?, name = ?, level = ?
      WHERE id = ?
    `,
      [data.category, data.name, data.level, data.id],
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating skill:", error)
    return NextResponse.json({ error: "Failed to update skill" }, { status: 500 })
  }
}

