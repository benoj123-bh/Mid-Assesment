import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await getDb()
    const profile = await db.get("SELECT * FROM profile LIMIT 1")

    return NextResponse.json(profile)
  } catch (error) {
    console.error("Error fetching profile:", error)
    return NextResponse.json({ error: "Failed to fetch profile" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    await db.run(
      `
      UPDATE profile 
      SET name = ?, title = ?, bio = ?, avatar = ?, email = ?, phone = ?, location = ?, github = ?, linkedin = ?, twitter = ?
      WHERE id = ?
    `,
      [
        data.name,
        data.title,
        data.bio,
        data.avatar,
        data.email,
        data.phone,
        data.location,
        data.github,
        data.linkedin,
        data.twitter,
        data.id,
      ],
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating profile:", error)
    return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
  }
}

