import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"
import { cookies } from "next/headers"

export async function POST(request: Request) {
  try {
    const { username, password } = await request.json()
    const db = await getDb()

    const user = await db.get("SELECT * FROM users WHERE username = ? AND password = ?", [username, password])

    if (!user) {
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // In a real app, you would use a proper authentication system
    // This is a simplified version for demonstration purposes
    cookies().set("auth", "authenticated", {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24, // 1 day
      path: "/",
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error during login:", error)
    return NextResponse.json({ error: "Authentication failed" }, { status: 500 })
  }
}

export async function DELETE() {
  cookies().delete("auth")
  return NextResponse.json({ success: true })
}

