import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await getDb()
    const projects = await db.all("SELECT * FROM projects")

    // Parse tags from comma-separated string to array
    const projectsWithParsedTags = projects.map((project) => ({
      ...project,
      tags: project.tags.split(","),
    }))

    return NextResponse.json(projectsWithParsedTags)
  } catch (error) {
    console.error("Error fetching projects:", error)
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    // Convert tags array to comma-separated string
    const tags = Array.isArray(data.tags) ? data.tags.join(",") : data.tags

    const result = await db.run(
      `
      INSERT INTO projects (title, description, image, tags, live_url, github_url, category)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `,
      [data.title, data.description, data.image, tags, data.live_url, data.github_url, data.category],
    )

    return NextResponse.json({
      id: result.lastID,
      ...data,
      tags: Array.isArray(data.tags) ? data.tags : data.tags.split(","),
    })
  } catch (error) {
    console.error("Error creating project:", error)
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    // Convert tags array to comma-separated string
    const tags = Array.isArray(data.tags) ? data.tags.join(",") : data.tags

    await db.run(
      `
      UPDATE projects 
      SET title = ?, description = ?, image = ?, tags = ?, live_url = ?, github_url = ?, category = ?
      WHERE id = ?
    `,
      [data.title, data.description, data.image, tags, data.live_url, data.github_url, data.category, data.id],
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating project:", error)
    return NextResponse.json({ error: "Failed to update project" }, { status: 500 })
  }
}

