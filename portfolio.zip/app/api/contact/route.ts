import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    await db.run(
      `
      INSERT INTO messages (name, email, subject, message)
      VALUES (?, ?, ?, ?)
    `,
      [data.name, data.email, data.subject, data.message],
    )

    return NextResponse.json({ success: true, message: "Message sent successfully!" })
  } catch (error) {
    console.error("Error sending message:", error)
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const db = await getDb()
    const messages = await db.all("SELECT * FROM messages ORDER BY created_at DESC")

    return NextResponse.json(messages)
  } catch (error) {
    console.error("Error fetching messages:", error)
    return NextResponse.json({ error: "Failed to fetch messages" }, { status: 500 })
  }
}

