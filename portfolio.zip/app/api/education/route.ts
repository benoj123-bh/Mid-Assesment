import { NextResponse } from "next/server"
import { getDb } from "@/lib/db"

export async function GET() {
  try {
    const db = await getDb()
    const education = await db.all("SELECT * FROM education ORDER BY start_date DESC")

    return NextResponse.json(education)
  } catch (error) {
    console.error("Error fetching education:", error)
    return NextResponse.json({ error: "Failed to fetch education" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    const result = await db.run(
      `
      INSERT INTO education (institution, degree, field, start_date, end_date, description)
      VALUES (?, ?, ?, ?, ?, ?)
    `,
      [data.institution, data.degree, data.field, data.start_date, data.end_date, data.description],
    )

    return NextResponse.json({ id: result.lastID, ...data })
  } catch (error) {
    console.error("Error creating education:", error)
    return NextResponse.json({ error: "Failed to create education" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const data = await request.json()
    const db = await getDb()

    await db.run(
      `
      UPDATE education 
      SET institution = ?, degree = ?, field = ?, start_date = ?, end_date = ?, description = ?
      WHERE id = ?
    `,
      [data.institution, data.degree, data.field, data.start_date, data.end_date, data.description, data.id],
    )

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error updating education:", error)
    return NextResponse.json({ error: "Failed to update education" }, { status: 500 })
  }
}

