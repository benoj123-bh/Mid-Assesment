"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/hooks/use-toast"
import { Pencil, Trash, Plus } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Skill {
  id: number
  category: string
  name: string
  level: number
}

export default function SkillsPage() {
  const [skills, setSkills] = useState<Skill[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [currentSkill, setCurrentSkill] = useState<Skill | null>(null)
  const { toast } = useToast()

  const fetchSkills = async () => {
    try {
      const response = await fetch("/api/skills")
      if (!response.ok) throw new Error("Failed to fetch skills")
      const data = await response.json()
      setSkills(data)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load skills data",
        variant: "destructive",
      })
    }
  }

  useEffect(() => {
    fetchSkills()
  }, [toast])

  const handleOpenDialog = (skill?: Skill) => {
    if (skill) {
      setCurrentSkill(skill)
    } else {
      setCurrentSkill({ id: 0, category: "Frontend", name: "", level: 50 })
    }
    setIsDialogOpen(true)
  }

  const handleCloseDialog = () => {
    setIsDialogOpen(false)
    setCurrentSkill(null)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement> | { name: string; value: string | number }) => {
    if (!currentSkill) return

    const { name, value } = "target" in e ? e.target : e
    setCurrentSkill({ ...currentSkill, [name]: value })
  }

  const handleSubmit = async () => {
    if (!currentSkill) return

    setIsLoading(true)

    try {
      const method = currentSkill.id ? "PUT" : "POST"
      const response = await fetch("/api/skills", {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(currentSkill),
      })

      if (!response.ok) throw new Error(`Failed to ${currentSkill.id ? "update" : "create"} skill`)

      toast({
        title: "Success",
        description: `Skill ${currentSkill.id ? "updated" : "created"} successfully`,
      })

      fetchSkills()
      handleCloseDialog()
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${currentSkill.id ? "update" : "create"} skill`,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this skill?")) return

    try {
      const response = await fetch(`/api/skills/${id}`, {
        method: "DELETE",
      })

      if (!response.ok) throw new Error("Failed to delete skill")

      toast({
        title: "Success",
        description: "Skill deleted successfully",
      })

      fetchSkills()
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete skill",
        variant: "destructive",
      })
    }
  }

  const categories = ["Frontend", "Backend", "Tools", "Other"]

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Manage Skills</h1>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="h-4 w-4 mr-2" />
          Add Skill
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {skills.map((skill) => (
          <Card key={skill.id}>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-lg">{skill.name}</CardTitle>
                  <p className="text-sm text-muted-foreground">{skill.category}</p>
                </div>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(skill)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(skill.id)}>
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Proficiency</span>
                  <span>{skill.level}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${skill.level}%` }} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{currentSkill?.id ? "Edit Skill" : "Add Skill"}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={currentSkill?.category}
                onValueChange={(value) => handleChange({ name: "category", value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="name">Skill Name</Label>
              <Input id="name" name="name" value={currentSkill?.name || ""} onChange={handleChange} required />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="level">Proficiency Level</Label>
                <span>{currentSkill?.level || 0}%</span>
              </div>
              <Slider
                id="level"
                min={0}
                max={100}
                step={5}
                value={[currentSkill?.level || 0]}
                onValueChange={(value) => handleChange({ name: "level", value: value[0] })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={handleCloseDialog}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isLoading}>
              {isLoading ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

