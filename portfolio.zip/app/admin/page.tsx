import { getDb } from "@/lib/db"
import type { Metadata } from "next"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Users, FileText, Mail } from "lucide-react"

export const metadata: Metadata = {
  title: "Admin Dashboard | Dynamic Portfolio",
  description: "Admin dashboard for managing portfolio content",
}

async function getDashboardData() {
  const db = await getDb()

  const skillsCount = await db.get("SELECT COUNT(*) as count FROM skills")
  const projectsCount = await db.get("SELECT COUNT(*) as count FROM projects")
  const educationCount = await db.get("SELECT COUNT(*) as count FROM education")
  const experienceCount = await db.get("SELECT COUNT(*) as count FROM experience")
  const messagesCount = await db.get("SELECT COUNT(*) as count FROM messages")

  const recentMessages = await db.all("SELECT * FROM messages ORDER BY created_at DESC LIMIT 5")

  return {
    counts: {
      skills: skillsCount.count,
      projects: projectsCount.count,
      education: educationCount.count,
      experience: experienceCount.count,
      messages: messagesCount.count,
    },
    recentMessages,
  }
}

export default async function AdminDashboard() {
  const { counts, recentMessages } = await getDashboardData()

  return (
    <div>
      <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Skills</CardTitle>
            <BarChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.skills}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.projects}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Education & Experience</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.education + counts.experience}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Messages</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{counts.messages}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Messages</CardTitle>
        </CardHeader>
        <CardContent>
          {recentMessages.length > 0 ? (
            <div className="space-y-4">
              {recentMessages.map((message) => (
                <div key={message.id} className="border-b pb-4">
                  <div className="flex justify-between">
                    <h3 className="font-medium">{message.name}</h3>
                    <span className="text-sm text-muted-foreground">
                      {new Date(message.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{message.email}</p>
                  <p className="font-medium mt-1">{message.subject}</p>
                  <p className="mt-2 text-sm">{message.message}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground">No messages yet.</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

