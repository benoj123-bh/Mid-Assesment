import { getDb } from "@/lib/db"
import type { Metadata } from "next"
import AboutSection from "@/components/about-section"

export const metadata: Metadata = {
  title: "About Me | Dynamic Portfolio",
  description: "Learn more about me and my background",
}

async function getProfile() {
  const db = await getDb()
  return db.get("SELECT * FROM profile LIMIT 1")
}

export default async function AboutPage() {
  const profile = await getProfile()

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">About Me</h1>
      <AboutSection profile={profile} />
    </div>
  )
}

