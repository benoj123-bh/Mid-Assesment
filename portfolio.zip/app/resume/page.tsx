import { getDb } from "@/lib/db"
import type { Metadata } from "next"
import ResumeSection from "@/components/resume-section"

export const metadata: Metadata = {
  title: "Resume | Dynamic Portfolio",
  description: "View my professional experience and education",
}

async function getData() {
  const db = await getDb()
  const profile = await db.get("SELECT * FROM profile LIMIT 1")
  const skills = await db.all("SELECT * FROM skills ORDER BY category, level DESC")
  const education = await db.all("SELECT * FROM education ORDER BY start_date DESC")
  const experience = await db.all("SELECT * FROM experience ORDER BY start_date DESC")

  return { profile, skills, education, experience }
}

export default async function ResumePage() {
  const { profile, skills, education, experience } = await getData()

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-4xl font-bold mb-8 text-center">Resume</h1>
      <ResumeSection profile={profile} skills={skills} education={education} experience={experience} />
    </div>
  )
}

