"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { User, BarChart, FileText, Briefcase, GraduationCap, Mail, LogOut, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

export default function AdminSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const { toast } = useToast()

  const handleLogout = async () => {
    try {
      await fetch("/api/auth", { method: "DELETE" })
      router.push("/admin/login")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to log out",
        variant: "destructive",
      })
    }
  }

  const navItems = [
    { href: "/admin", label: "Dashboard", icon: <BarChart className="h-5 w-5" /> },
    { href: "/admin/profile", label: "Profile", icon: <User className="h-5 w-5" /> },
    { href: "/admin/skills", label: "Skills", icon: <BarChart className="h-5 w-5" /> },
    { href: "/admin/projects", label: "Projects", icon: <FileText className="h-5 w-5" /> },
    { href: "/admin/experience", label: "Experience", icon: <Briefcase className="h-5 w-5" /> },
    { href: "/admin/education", label: "Education", icon: <GraduationCap className="h-5 w-5" /> },
    { href: "/admin/messages", label: "Messages", icon: <Mail className="h-5 w-5" /> },
  ]

  return (
    <div className="w-64 bg-muted/30 h-screen p-4 flex flex-col">
      <div className="mb-8 flex items-center justify-center">
        <h1 className="text-2xl font-bold text-primary">Admin Panel</h1>
      </div>

      <nav className="space-y-2 flex-grow">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex items-center gap-3 px-4 py-2 rounded-md transition-colors ${
              pathname === item.href ? "bg-primary text-primary-foreground" : "hover:bg-muted"
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </Link>
        ))}

        <Link
          href="/"
          className="flex items-center gap-3 px-4 py-2 rounded-md transition-colors hover:bg-muted"
          target="_blank"
        >
          <Home className="h-5 w-5" />
          <span>View Site</span>
        </Link>
      </nav>

      <Button variant="outline" className="mt-auto w-full" onClick={handleLogout}>
        <LogOut className="h-5 w-5 mr-2" />
        Logout
      </Button>
    </div>
  )
}

