"use client"
import { Calendar, MapPin, Briefcase, GraduationCap } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Profile {
  name: string
  title: string
  bio: string
}

interface Skill {
  id: number
  category: string
  name: string
  level: number
}

interface Education {
  id: number
  institution: string
  degree: string
  field: string
  start_date: string
  end_date: string | null
  description: string | null
}

interface Experience {
  id: number
  company: string
  position: string
  start_date: string
  end_date: string | null
  description: string | null
  location: string | null
}

export default function ResumeSection({
  profile,
  skills,
  education,
  experience,
}: {
  profile: Profile
  skills: Skill[]
  education: Education[]
  experience: Experience[]
}) {
  // Group skills by category
  const categories = Array.from(new Set(skills.map((skill) => skill.category)))
  const skillsByCategory = categories.map((category) => ({
    category,
    items: skills.filter((skill) => skill.category === category),
  }))

  // Format date function
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Present"
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long" })
  }

  return (
    <div className="space-y-12">
      {/* Profile Summary */}
      <section>
        <h2 className="text-2xl font-bold mb-4">Professional Summary</h2>
        <p className="text-muted-foreground">{profile.bio}</p>

        <div className="mt-6">
          <Button>Download CV</Button>
        </div>
      </section>

      {/* Skills */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Skills</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillsByCategory.map((skillGroup) => (
            <div key={skillGroup.category} className="bg-card rounded-lg shadow-sm p-6">
              <h3 className="text-xl font-bold mb-6 text-center">{skillGroup.category}</h3>
              <div className="space-y-6">
                {skillGroup.items.map((skill) => (
                  <div key={skill.id}>
                    <div className="flex justify-between mb-2">
                      <span className="font-medium">{skill.name}</span>
                      <span className="text-muted-foreground">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary" style={{ width: `${skill.level}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Education */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Education</h2>

        <div className="space-y-8">
          {education.map((edu) => (
            <div key={edu.id} className="bg-card rounded-lg shadow-sm p-6">
              <div className="flex items-start">
                <div className="mr-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <GraduationCap className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold">
                    {edu.degree} in {edu.field}
                  </h3>
                  <h4 className="text-lg text-primary">{edu.institution}</h4>
                  <div className="flex items-center text-muted-foreground mt-2">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span>
                      {formatDate(edu.start_date)} - {formatDate(edu.end_date)}
                    </span>
                  </div>
                  {edu.description && <p className="mt-4">{edu.description}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Experience */}
      <section>
        <h2 className="text-2xl font-bold mb-6">Work Experience</h2>

        <div className="space-y-8">
          {experience.map((exp) => (
            <div key={exp.id} className="bg-card rounded-lg shadow-sm p-6">
              <div className="flex items-start">
                <div className="mr-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Briefcase className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-bold">{exp.position}</h3>
                  <h4 className="text-lg text-primary">{exp.company}</h4>
                  <div className="flex flex-wrap gap-4 text-muted-foreground mt-2">
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      <span>
                        {formatDate(exp.start_date)} - {formatDate(exp.end_date)}
                      </span>
                    </div>
                    {exp.location && (
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        <span>{exp.location}</span>
                      </div>
                    )}
                  </div>
                  {exp.description && <p className="mt-4">{exp.description}</p>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

