"use client"
import { MapPin, Mail, Phone, Github, Linkedin, Twitter } from "lucide-react"

interface Profile {
  name: string
  title: string
  bio: string
  avatar: string
  email: string
  phone: string
  location: string
  github: string
  linkedin: string
  twitter: string
}

export default function AboutSection({ profile }: { profile: Profile }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
      <div>
        <div className="aspect-square rounded-lg overflow-hidden mb-6">
          <img
            src={profile?.avatar || "/placeholder.svg?height=600&width=600"}
            alt={profile?.name || "Profile"}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Contact Information</h2>

          <div className="space-y-3">
            {profile?.email && (
              <div className="flex items-center">
                <Mail className="h-5 w-5 text-primary mr-3" />
                <span>{profile.email}</span>
              </div>
            )}

            {profile?.phone && (
              <div className="flex items-center">
                <Phone className="h-5 w-5 text-primary mr-3" />
                <span>{profile.phone}</span>
              </div>
            )}

            {profile?.location && (
              <div className="flex items-center">
                <MapPin className="h-5 w-5 text-primary mr-3" />
                <span>{profile.location}</span>
              </div>
            )}
          </div>

          <h2 className="text-2xl font-bold pt-4">Social Media</h2>

          <div className="flex space-x-4">
            {profile?.github && (
              <a
                href={profile.github}
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Github className="h-5 w-5" />
              </a>
            )}

            {profile?.linkedin && (
              <a
                href={profile.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            )}

            {profile?.twitter && (
              <a
                href={profile.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
              >
                <Twitter className="h-5 w-5" />
              </a>
            )}
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-3xl font-bold mb-6">{profile?.name || "About Me"}</h2>
        <h3 className="text-xl text-primary mb-4">{profile?.title || "Web Developer"}</h3>

        <div className="prose dark:prose-invert max-w-none">
          <p className="text-lg mb-6">{profile?.bio || "Loading bio..."}</p>

          <h3 className="text-2xl font-bold mb-4">My Mission</h3>
          <p className="mb-6">
            My mission is to create beautiful, functional, and user-friendly websites and applications that solve
            real-world problems. I am passionate about using technology to make a positive impact on people's lives.
          </p>

          <h3 className="text-2xl font-bold mb-4">My Approach</h3>
          <p>
            I believe in a collaborative approach to web development, working closely with clients to understand their
            needs and goals. I focus on creating clean, efficient, and maintainable code that delivers a seamless user
            experience.
          </p>
        </div>
      </div>
    </div>
  )
}

