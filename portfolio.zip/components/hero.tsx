"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ArrowDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface Profile {
  name: string
  title: string
}

export default function Hero() {
  const [scrollY, setScrollY] = useState(0)
  const [profile, setProfile] = useState<Profile | null>(null)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch("/api/profile")
        if (response.ok) {
          const data = await response.json()
          setProfile(data)
        }
      } catch (error) {
        console.error("Failed to fetch profile data for hero")
      }
    }

    fetchProfile()
  }, [])

  return (
    <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-gradient-to-b from-primary/10 to-background z-0"
        style={{
          opacity: Math.min(scrollY / 500, 0.5),
        }}
      />

      <motion.div
        className="text-center z-10 px-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-4">
          <span className="text-primary">Hello, I'm</span> <br />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-primary to-purple-600">
            {profile?.name || "John Doe"}
          </span>
        </h1>
        <h2 className="text-xl md:text-2xl text-muted-foreground mb-8">
          {profile?.title || "Full Stack Developer & UI/UX Designer"}
        </h2>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="px-8" asChild>
            <Link href="/resume">View My Resume</Link>
          </Button>
          <Button size="lg" variant="outline" className="px-8" asChild>
            <Link href="/contact">Contact Me</Link>
          </Button>
        </div>
      </motion.div>

      <motion.div
        className="absolute bottom-10"
        animate={{
          y: [0, 10, 0],
        }}
        transition={{
          repeat: Number.POSITIVE_INFINITY,
          duration: 1.5,
        }}
      >
        <ArrowDown className="h-8 w-8 text-primary" />
      </motion.div>
    </section>
  )
}

