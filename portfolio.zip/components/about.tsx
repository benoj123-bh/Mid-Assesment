"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { MapPin, Mail, Phone } from "lucide-react"

interface Profile {
  name: string
  title: string
  bio: string
  avatar: string
  email: string
  phone: string
  location: string
}

export default function About() {
  const [profile, setProfile] = useState<Profile | null>(null)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await fetch("/api/profile")
        if (response.ok) {
          const data = await response.json()
          setProfile(data)
        }
      } catch (error) {
        console.error("Failed to fetch profile data")
      }
    }

    fetchProfile()
  }, [])

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">About Me</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get to know more about me, my background, and what I do.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
            <div className="relative">
              <div className="aspect-square rounded-lg overflow-hidden">
                <img
                  src={profile?.avatar || "/placeholder.svg?height=600&width=600"}
                  alt={profile?.name || "Profile"}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-4 rounded-lg shadow-lg">
                <p className="text-lg font-bold">Web Developer</p>
              </div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
            <h3 className="text-2xl font-bold mb-4">Who am I?</h3>
            <p className="text-muted-foreground mb-6">{profile?.bio || "Loading bio..."}</p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {profile?.location && (
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-primary mr-2" />
                  <span>{profile.location}</span>
                </div>
              )}

              {profile?.email && (
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-primary mr-2" />
                  <span>{profile.email}</span>
                </div>
              )}

              {profile?.phone && (
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-primary mr-2" />
                  <span>{profile.phone}</span>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

