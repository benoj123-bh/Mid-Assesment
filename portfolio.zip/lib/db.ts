// In-memory database for browser compatibility
const db = {
  profile: null as any,
  skills: [] as any[],
  education: [] as any[],
  experience: [] as any[],
  projects: [] as any[],
  messages: [] as any[],
  users: [] as any[],
}

// Initialize with default data
let isInitialized = false

export async function getDb() {
  if (!isInitialized) {
    // Initialize default profile
    db.profile = {
      id: 1,
      name: "Benoj Karki",
      title: "Full Stack Developer & UI/UX Designer",
      bio: "I am a passionate developer with expertise in building responsive and performant web applications.",
      avatar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-vdXs2NMqM0nBsqWdrlcEwTXCTNMmmZ.png",
      email: "benojkarki@gmail.com",
      phone: "9748263004",
      location: "Godawari, Lalitpur",
      github: "https://github.com",
      linkedin: "https://linkedin.com",
      twitter: "https://twitter.com",
    }

    // Initialize default skills
    db.skills = [
      { id: 1, category: "Frontend", name: "HTML/CSS", level: 90 },
      { id: 2, category: "Frontend", name: "JavaScript", level: 85 },
      { id: 3, category: "Frontend", name: "React", level: 80 },
      { id: 4, category: "Frontend", name: "Next.js", level: 75 },
      { id: 5, category: "Backend", name: "Node.js", level: 80 },
      { id: 6, category: "Backend", name: "Express", level: 75 },
      { id: 7, category: "Backend", name: "SQLite", level: 70 },
      { id: 8, category: "Tools", name: "Git/GitHub", level: 85 },
      { id: 9, category: "Tools", name: "Docker", level: 65 },
    ]

    // Initialize default education
    db.education = [
      {
        id: 1,
        institution: "Texas College of Management & IT",
        degree: "Bachelor",
        field: "Information Technology",
        start_date: "2020-09-01",
        end_date: "2024-06-30",
        description: "Studied web development, database management, and software engineering.",
      },
    ]

    // Initialize default experience
    db.experience = [
      {
        id: 1,
        company: "Tech Solutions Inc.",
        position: "Web Developer",
        start_date: "2022-01-01",
        end_date: null,
        description: "Developing and maintaining web applications using React and Node.js.",
        location: "New York, USA",
      },
    ]

    // Initialize default projects
    db.projects = [
      {
        id: 1,
        title: "AB Choco Fantasy",
        description:
          "An e-commerce platform for a chocolate brand with product catalog, shopping cart, and subscription features.",
        image:
          "https://sjc.microlink.io/WMRjD64WnmG0UmUc9CPw19EOaYb04VEHZvPQ61G4s6H5fHcBZAtr4gjiVI3ylzFda_AiQbO0ibhaGsUVmyF0Rg.jpeg",
        tags: "HTML,CSS,JavaScript,E-commerce,Weebly",
        live_url: "https://ab-choco-fantasy.weeblysite.com/",
        github_url: "",
        category: "e-commerce",
      },
      {
        id: 2,
        title: "E-Commerce Platform",
        description: "A full-stack e-commerce platform with payment integration and user authentication.",
        image: "/placeholder.svg?height=400&width=600",
        tags: "React,Node.js,MongoDB,Stripe",
        live_url: "https://example.com",
        github_url: "https://github.com",
        category: "fullstack",
      },
      {
        id: 3,
        title: "Portfolio Website",
        description: "A responsive portfolio website built with Next.js and Tailwind CSS.",
        image: "/placeholder.svg?height=400&width=600",
        tags: "Next.js,Tailwind CSS,SQLite",
        live_url: "https://example.com",
        github_url: "https://github.com",
        category: "frontend",
      },
    ]

    // Initialize default users
    db.users = [
      {
        id: 1,
        username: "admin",
        password: "admin123",
      },
    ]

    // Initialize messages
    db.messages = []

    isInitialized = true
  }

  // Return a database-like interface
  return {
    get: async (query: string, params?: any[]) => {
      // Simple query parser for SELECT statements
      if (query.includes("FROM profile")) {
        return db.profile
      } else if (query.includes("COUNT(*) as count FROM skills")) {
        return { count: db.skills.length }
      } else if (query.includes("COUNT(*) as count FROM education")) {
        return { count: db.education.length }
      } else if (query.includes("COUNT(*) as count FROM experience")) {
        return { count: db.experience.length }
      } else if (query.includes("COUNT(*) as count FROM projects")) {
        return { count: db.projects.length }
      } else if (query.includes("COUNT(*) as count FROM messages")) {
        return { count: db.messages.length }
      } else if (query.includes("COUNT(*) as count FROM users")) {
        return { count: db.users.length }
      } else if (query.includes("FROM users WHERE username")) {
        const [username, password] = params || []
        return db.users.find((user) => user.username === username && user.password === password) || null
      }
      return null
    },
    all: async (query: string) => {
      // Simple query parser for SELECT statements
      if (query.includes("FROM skills")) {
        return [...db.skills]
      } else if (query.includes("FROM education")) {
        return [...db.education]
      } else if (query.includes("FROM experience")) {
        return [...db.experience]
      } else if (query.includes("FROM projects")) {
        return db.projects.map((project) => ({
          ...project,
          tags: typeof project.tags === "string" ? project.tags.split(",") : project.tags,
        }))
      } else if (query.includes("FROM messages")) {
        return [...db.messages]
      }
      return []
    },
    run: async (query: string, params?: any[]) => {
      // Simple query parser for INSERT, UPDATE, DELETE statements
      if (query.includes("INSERT INTO profile")) {
        db.profile = {
          id: 1,
          name: params?.[0] || "",
          title: params?.[1] || "",
          bio: params?.[2] || "",
          avatar: params?.[3] || "",
          email: params?.[4] || "",
          phone: params?.[5] || "",
          location: params?.[6] || "",
          github: params?.[7] || "",
          linkedin: params?.[8] || "",
          twitter: params?.[9] || "",
        }
        return { lastID: 1 }
      } else if (query.includes("UPDATE profile")) {
        db.profile = {
          ...db.profile,
          name: params?.[0] || db.profile.name,
          title: params?.[1] || db.profile.title,
          bio: params?.[2] || db.profile.bio,
          avatar: params?.[3] || db.profile.avatar,
          email: params?.[4] || db.profile.email,
          phone: params?.[5] || db.profile.phone,
          location: params?.[6] || db.profile.location,
          github: params?.[7] || db.profile.github,
          linkedin: params?.[8] || db.profile.linkedin,
          twitter: params?.[9] || db.profile.twitter,
        }
        return { changes: 1 }
      } else if (query.includes("INSERT INTO skills")) {
        const newSkill = {
          id: db.skills.length + 1,
          category: params?.[0] || "",
          name: params?.[1] || "",
          level: params?.[2] || 0,
        }
        db.skills.push(newSkill)
        return { lastID: newSkill.id }
      } else if (query.includes("UPDATE skills")) {
        const id = params?.[3]
        const index = db.skills.findIndex((skill) => skill.id === id)
        if (index !== -1) {
          db.skills[index] = {
            ...db.skills[index],
            category: params?.[0] || db.skills[index].category,
            name: params?.[1] || db.skills[index].name,
            level: params?.[2] || db.skills[index].level,
          }
        }
        return { changes: index !== -1 ? 1 : 0 }
      } else if (query.includes("DELETE FROM skills")) {
        const id = params?.[0]
        const initialLength = db.skills.length
        db.skills = db.skills.filter((skill) => skill.id !== Number(id))
        return { changes: initialLength - db.skills.length }
      } else if (query.includes("INSERT INTO education")) {
        const newEducation = {
          id: db.education.length + 1,
          institution: params?.[0] || "",
          degree: params?.[1] || "",
          field: params?.[2] || "",
          start_date: params?.[3] || "",
          end_date: params?.[4] || null,
          description: params?.[5] || null,
        }
        db.education.push(newEducation)
        return { lastID: newEducation.id }
      } else if (query.includes("UPDATE education")) {
        const id = params?.[6]
        const index = db.education.findIndex((edu) => edu.id === id)
        if (index !== -1) {
          db.education[index] = {
            ...db.education[index],
            institution: params?.[0] || db.education[index].institution,
            degree: params?.[1] || db.education[index].degree,
            field: params?.[2] || db.education[index].field,
            start_date: params?.[3] || db.education[index].start_date,
            end_date: params?.[4],
            description: params?.[5],
          }
        }
        return { changes: index !== -1 ? 1 : 0 }
      } else if (query.includes("DELETE FROM education")) {
        const id = params?.[0]
        const initialLength = db.education.length
        db.education = db.education.filter((edu) => edu.id !== Number(id))
        return { changes: initialLength - db.education.length }
      } else if (query.includes("INSERT INTO experience")) {
        const newExperience = {
          id: db.experience.length + 1,
          company: params?.[0] || "",
          position: params?.[1] || "",
          start_date: params?.[2] || "",
          end_date: params?.[3] || null,
          description: params?.[4] || null,
          location: params?.[5] || null,
        }
        db.experience.push(newExperience)
        return { lastID: newExperience.id }
      } else if (query.includes("UPDATE experience")) {
        const id = params?.[6]
        const index = db.experience.findIndex((exp) => exp.id === id)
        if (index !== -1) {
          db.experience[index] = {
            ...db.experience[index],
            company: params?.[0] || db.experience[index].company,
            position: params?.[1] || db.experience[index].position,
            start_date: params?.[2] || db.experience[index].start_date,
            end_date: params?.[3],
            description: params?.[4],
            location: params?.[5],
          }
        }
        return { changes: index !== -1 ? 1 : 0 }
      } else if (query.includes("DELETE FROM experience")) {
        const id = params?.[0]
        const initialLength = db.experience.length
        db.experience = db.experience.filter((exp) => exp.id !== Number(id))
        return { changes: initialLength - db.experience.length }
      } else if (query.includes("INSERT INTO projects")) {
        const newProject = {
          id: db.projects.length + 1,
          title: params?.[0] || "",
          description: params?.[1] || "",
          image: params?.[2] || "",
          tags: params?.[3] || "",
          live_url: params?.[4] || "",
          github_url: params?.[5] || "",
          category: params?.[6] || "",
        }
        db.projects.push(newProject)
        return { lastID: newProject.id }
      } else if (query.includes("UPDATE projects")) {
        const id = params?.[7]
        const index = db.projects.findIndex((project) => project.id === id)
        if (index !== -1) {
          db.projects[index] = {
            ...db.projects[index],
            title: params?.[0] || db.projects[index].title,
            description: params?.[1] || db.projects[index].description,
            image: params?.[2] || db.projects[index].image,
            tags: params?.[3] || db.projects[index].tags,
            live_url: params?.[4] || db.projects[index].live_url,
            github_url: params?.[5] || db.projects[index].github_url,
            category: params?.[6] || db.projects[index].category,
          }
        }
        return { changes: index !== -1 ? 1 : 0 }
      } else if (query.includes("DELETE FROM projects")) {
        const id = params?.[0]
        const initialLength = db.projects.length
        db.projects = db.projects.filter((project) => project.id !== Number(id))
        return { changes: initialLength - db.projects.length }
      } else if (query.includes("INSERT INTO messages")) {
        const now = new Date().toISOString()
        const newMessage = {
          id: db.messages.length + 1,
          name: params?.[0] || "",
          email: params?.[1] || "",
          subject: params?.[2] || "",
          message: params?.[3] || "",
          created_at: now,
        }
        db.messages.push(newMessage)
        return { lastID: newMessage.id }
      } else if (query.includes("INSERT INTO users")) {
        const newUser = {
          id: db.users.length + 1,
          username: params?.[0] || "",
          password: params?.[1] || "",
        }
        db.users.push(newUser)
        return { lastID: newUser.id }
      }
      return { changes: 0, lastID: null }
    },
    exec: async (query: string) => {
      // This is a no-op for our in-memory DB
      return
    },
    close: async () => {
      // This is a no-op for our in-memory DB
      return
    },
  }
}

export async function closeDb() {
  // No-op for in-memory DB
  return
}

